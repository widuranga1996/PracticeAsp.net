﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Threading.Tasks;
using Microsoft.EntityFrameworkCore;

namespace FinalPractice.Models
{
    public class FinalPracticeContext : DbContext
    {
        public FinalPracticeContext (DbContextOptions<FinalPracticeContext> options)
            : base(options)
        {
        }

        public DbSet<FinalPractice.Models.Person> Person { get; set; }
    }
}
