﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Threading.Tasks;
using Microsoft.AspNetCore.Mvc;
using System.Text.Encodings.Web;
using FinalPractice.Models;

// For more information on enabling MVC for empty projects, visit https://go.microsoft.com/fwlink/?LinkID=397860

namespace FinalPractice.Controllers
{
    public class StudentController : Controller
    {
        // GET: /<controller>/
        public IActionResult Index()
        {
            Person person = new Person();
            person.Name = "Amal";
            person.Designation = "Software engineer";
            List<Person> par = new List<Person>();
            par.Add(person);
            return View(par);
        }

        //public String Person()
        //{
        //    return HtmlEncoder.Default.Encode("This is Person method");
        //}
    }

        
}
