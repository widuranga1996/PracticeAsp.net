﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Threading.Tasks;

namespace FinalPractice.Models
{
    public class Person
    {
        public int ID { get; set; }
        public String Name { get; set; }
        public String Designation { get; set; }
        public decimal Salary { get; set; }
    }
}
